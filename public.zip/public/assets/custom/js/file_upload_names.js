updateList = function() {
  var input = document.getElementById('attachments');
  var output = document.getElementById('attachmentsList');

  output.innerHTML = '<ul>';
  for (var i = 0; i < input.files.length; ++i) {
    output.innerHTML += input.files.item(i).name + ', ';
  }
  output.innerHTML += '</ul>';
}